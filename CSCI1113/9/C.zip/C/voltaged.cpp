#include <iostream>

#include "VoltageDivider.h"
#include "resistor.h"
using namespace std;


int main
{
	double a,b,c,d;
	resistor r1,r2;
	
	cout<<"please input the nominal values of resister 1 & 2, then input the tolerance % of resistor 1 & 2."<<endl;
	cin>>a,b,c,d;
	r1.n_resistance=a;
	r2.n_resistance=b;
	r1.tolerance=c;
	r2.tolerance=d;
	VoltageDivider x(r1,r2);
	cout<<"nominal value of gain is "<<x.gainnr<<", and the actual value of gain is "<<x.gainr<<endl;
	
	return 0;
	
}
