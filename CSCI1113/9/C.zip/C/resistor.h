#ifndef RESISTOR_H
#define RESISTOR_H


class resistor
{
	public:
		resistor(double, double);
		

	private:
		double n_resistance;
		double tolerance;
		double actual_r;
	
};




#endif
