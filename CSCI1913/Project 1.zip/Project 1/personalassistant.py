"""personalassistant is a python program used to retrieve and store contacts
   along with other handy features, such as giving the current temperature"""

__author__="Your Name"
__date__=""

# add your imports here #
from contacts import Contact


def main():
	"TODO"






main()
