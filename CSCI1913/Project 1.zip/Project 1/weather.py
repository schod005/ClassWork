
"""This module is a web scraper that has functions that are useful for gathering weather data from bing."""

import sys
import urllib

__author__="Your Names"
__date__=""

def grabTempFahrenheit(city):
	"TODO"

def grabTempCelsius(city):
	"TODO"

def getHumidity(city):
	"TODO"

def getHighTemp(city):
    "TODO"

def getLowTemp(city):
    "TODO"

def getCurrentCondition(city):
	"TODO"

def getWindSpeed(city):
	"TODO"

def getWindChillFahrenheit(wind_speed_mph, degrees_F):
	"TODO"
